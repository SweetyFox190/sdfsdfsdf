import { useEffect, useMemo, useState } from "react";

type TaskType = "Один ответ" | "Несколько ответов" | "Сопоставление" | "Последовательность";
type Difficulty = "Легко" | "Средне" | "Сложно";

type Task = {
  id: number;
  title: string;
  description: string;
  type: TaskType;
  difficulty: Difficulty;
  items: number;
  duration: number;
  author: string;
  color: string;
};

const starterTasks: Task[] = [
  {
    id: 1,
    title: "Методы массивов JavaScript",
    description: "Проверьте, насколько уверенно вы работаете с массивами и их методами.",
    type: "Один ответ",
    difficulty: "Легко",
    items: 8,
    duration: 5,
    author: "Анна Морозова",
    color: "lime",
  },
  {
    id: 2,
    title: "Frontend или Backend?",
    description: "Распределите технологии по направлениям веб-разработки.",
    type: "Сопоставление",
    difficulty: "Средне",
    items: 12,
    duration: 8,
    author: "Максим Ветров",
    color: "violet",
  },
  {
    id: 3,
    title: "Этапы разработки продукта",
    description: "Восстановите правильный порядок работы над цифровым продуктом.",
    type: "Последовательность",
    difficulty: "Легко",
    items: 6,
    duration: 4,
    author: "Ольга Рэй",
    color: "orange",
  },
  {
    id: 4,
    title: "Типы данных без ошибок",
    description: "Выберите все корректные типы данных и закрепите базовые понятия.",
    type: "Несколько ответов",
    difficulty: "Средне",
    items: 10,
    duration: 7,
    author: "Илья Круглов",
    color: "blue",
  },
  {
    id: 5,
    title: "Найди ошибку в коде",
    description: "Разберите короткие фрагменты кода и найдите скрытые ошибки.",
    type: "Один ответ",
    difficulty: "Сложно",
    items: 9,
    duration: 12,
    author: "Саша Лин",
    color: "pink",
  },
  {
    id: 6,
    title: "HTML: семантика страницы",
    description: "Сопоставьте элементы интерфейса с подходящими HTML-тегами.",
    type: "Сопоставление",
    difficulty: "Средне",
    items: 14,
    duration: 9,
    author: "Лиза Соколова",
    color: "cyan",
  },
];

const typeOptions = ["Все типы", "Один ответ", "Несколько ответов", "Сопоставление", "Последовательность"];
const difficultyOptions = ["Любая сложность", "Легко", "Средне", "Сложно"];

function Button({
  children,
  variant = "primary",
  className = "",
  ...props
}: React.ButtonHTMLAttributes<HTMLButtonElement> & { variant?: "primary" | "secondary" | "ghost" }) {
  return (
    <button className={`button button--${variant} ${className}`} {...props}>
      {children}
    </button>
  );
}

function Icon({ name }: { name: "search" | "spark" | "book" | "time" | "arrow" | "plus" | "check" }) {
  const paths = {
    search: <><circle cx="11" cy="11" r="6" /><path d="m16 16 4 4" /></>,
    spark: <><path d="M12 2l1.7 5.3L19 9l-5.3 1.7L12 16l-1.7-5.3L5 9l5.3-1.7L12 2Z" /><path d="m5 16 .7 2.3L8 19l-2.3.7L5 22l-.7-2.3L2 19l2.3-.7L5 16Z" /></>,
    book: <><path d="M4 5.5A3.5 3.5 0 0 1 7.5 2H11v17H7a3 3 0 0 0-3 3V5.5Z" /><path d="M20 5.5A3.5 3.5 0 0 0 16.5 2H13v17h4a3 3 0 0 1 3 3V5.5Z" /></>,
    time: <><circle cx="12" cy="12" r="9" /><path d="M12 7v5l3 2" /></>,
    arrow: <><path d="M5 12h14" /><path d="m14 7 5 5-5 5" /></>,
    plus: <><path d="M12 5v14M5 12h14" /></>,
    check: <path d="m5 12 4 4L19 6" />,
  };
  return <svg className="icon" viewBox="0 0 24 24" aria-hidden="true">{paths[name]}</svg>;
}

function TaskCard({ task, onStart }: { task: Task; onStart: (task: Task) => void }) {
  return (
    <article className="task-card">
      <div className={`task-card__visual visual--${task.color}`}>
        <div className="visual-orbit visual-orbit--one" />
        <div className="visual-orbit visual-orbit--two" />
        <span className="visual-mark">{task.id.toString().padStart(2, "0")}</span>
        <span className="type-pill">{task.type}</span>
      </div>
      <div className="task-card__body">
        <div className="task-card__meta">
          <span className={`difficulty difficulty--${task.difficulty.toLowerCase()}`}>{task.difficulty}</span>
          <span>{task.items} заданий</span>
          <span>·</span>
          <span>{task.duration} мин</span>
        </div>
        <div className="task-card__title">{task.title}</div>
        <p>{task.description}</p>
        <div className="task-card__footer">
          <div className="author"><span>{task.author.slice(0, 1)}</span>{task.author}</div>
          <Button variant="secondary" onClick={() => onStart(task)}>Начать <Icon name="arrow" /></Button>
        </div>
      </div>
    </article>
  );
}

function CreatePanel({ onClose, onCreate }: { onClose: () => void; onCreate: (task: Task) => void }) {
  const [title, setTitle] = useState("");
  const [type, setType] = useState<TaskType>("Один ответ");
  const [difficulty, setDifficulty] = useState<Difficulty>("Легко");

  function submit(event: React.FormEvent) {
    event.preventDefault();
    if (!title.trim()) return;
    onCreate({
      id: Date.now(),
      title: title.trim(),
      description: "Новое интерактивное задание — добавьте вопросы и пригласите учеников.",
      type,
      difficulty,
      items: 5,
      duration: 5,
      author: "Вы",
      color: "lime",
    });
  }

  return (
    <div className="overlay" onMouseDown={onClose}>
      <form className="create-panel" onSubmit={submit} onMouseDown={(event) => event.stopPropagation()}>
        <div className="create-panel__step">Новый проект · шаг 1 из 3</div>
        <div className="create-panel__title">Создайте задание</div>
        <p>Начните с основы. Вопросы и правильные ответы добавим на следующем шаге.</p>
        <label>
          Название задания
          <input autoFocus value={title} onChange={(event) => setTitle(event.target.value)} placeholder="Например, Основы CSS Grid" />
        </label>
        <div className="form-grid">
          <label>
            Тип
            <select value={type} onChange={(event) => setType(event.target.value as TaskType)}>
              {typeOptions.slice(1).map((option) => <option key={option}>{option}</option>)}
            </select>
          </label>
          <label>
            Сложность
            <select value={difficulty} onChange={(event) => setDifficulty(event.target.value as Difficulty)}>
              {difficultyOptions.slice(1).map((option) => <option key={option}>{option}</option>)}
            </select>
          </label>
        </div>
        <div className="create-panel__actions">
          <Button type="button" variant="ghost" onClick={onClose}>Отмена</Button>
          <Button type="submit">Создать основу <Icon name="arrow" /></Button>
        </div>
      </form>
    </div>
  );
}

function TaskPlayer({ task, onClose }: { task: Task; onClose: () => void }) {
  const [answer, setAnswer] = useState("");
  const [checked, setChecked] = useState(false);
  const options = ["push()", "pop()", "shift()", "slice()"];
  return (
    <div className="player-page">
      <header className="player-header">
        <Button variant="ghost" onClick={onClose}>← К витрине</Button>
        <div className="player-progress"><span style={{ width: "12.5%" }} /></div>
        <span>1 / {task.items}</span>
      </header>
      <main className="player">
        <div className="player__eyebrow">{task.type} · {task.title}</div>
        <div className="player__title">Какой метод добавляет элемент в конец массива JavaScript?</div>
        <p>Выберите один вариант ответа.</p>
        <div className="answer-list">
          {options.map((option, index) => (
            <button
              key={option}
              className={`answer ${answer === option ? "answer--selected" : ""} ${checked && option === "push()" ? "answer--correct" : ""}`}
              onClick={() => !checked && setAnswer(option)}
            >
              <span>{String.fromCharCode(65 + index)}</span>
              {option}
              {checked && option === "push()" && <Icon name="check" />}
            </button>
          ))}
        </div>
        {checked && <div className="feedback"><Icon name="check" /><div><strong>Верно!</strong><p>Метод push() добавляет один или несколько элементов в конец массива.</p></div></div>}
        <Button className="player__action" disabled={!answer} onClick={() => setChecked(true)}>
          {checked ? "Следующий вопрос" : "Проверить ответ"} <Icon name="arrow" />
        </Button>
      </main>
    </div>
  );
}

export default function App() {
  const [tasks, setTasks] = useState<Task[]>(() => {
    const saved = localStorage.getItem("interactive-tasks");
    return saved ? JSON.parse(saved) : starterTasks;
  });
  const [query, setQuery] = useState("");
  const [type, setType] = useState("Все типы");
  const [difficulty, setDifficulty] = useState("Любая сложность");
  const [createOpen, setCreateOpen] = useState(false);
  const [activeTask, setActiveTask] = useState<Task | null>(null);

  useEffect(() => {
    localStorage.setItem("interactive-tasks", JSON.stringify(tasks));
  }, [tasks]);

  const filtered = useMemo(() => tasks.filter((task) => {
    const matchesQuery = task.title.toLowerCase().includes(query.toLowerCase());
    const matchesType = type === "Все типы" || task.type === type;
    const matchesDifficulty = difficulty === "Любая сложность" || task.difficulty === difficulty;
    return matchesQuery && matchesType && matchesDifficulty;
  }), [tasks, query, type, difficulty]);

  function createTask(task: Task) {
    setTasks((current) => [task, ...current]);
    setCreateOpen(false);
  }

  if (activeTask) return <TaskPlayer task={activeTask} onClose={() => setActiveTask(null)} />;

  return (
    <div className="app">
      <header className="site-header">
        <a className="brand" href="#"><span>IT</span><b>Taskflow</b></a>
        <nav>
          <a className="active" href="#catalog">Витрина</a>
          <a href="#catalog">Все задания</a>
          <a href="#how">Как это работает</a>
        </nav>
        <div className="header-actions">
          <Button variant="ghost">Мои задания</Button>
          <Button onClick={() => setCreateOpen(true)}><Icon name="plus" /> Создать</Button>
          <button className="avatar" aria-label="Профиль">АК</button>
        </div>
      </header>

      <main>
        <section className="hero">
          <div className="hero__content">
            <div className="eyebrow"><Icon name="spark" /> Учиться — значит пробовать</div>
            <div className="hero__title">Задания, которые хочется <em>решать</em></div>
            <p>Создавайте интерактивные упражнения без кода. Делитесь с учениками и получайте результат сразу.</p>
            <div className="hero__actions">
              <Button onClick={() => setCreateOpen(true)}>Создать задание <Icon name="arrow" /></Button>
              <Button variant="secondary" onClick={() => document.querySelector("#catalog")?.scrollIntoView({ behavior: "smooth" })}>Смотреть каталог</Button>
            </div>
            <div className="hero__proof">
              <div className="avatars"><span>А</span><span>М</span><span>О</span></div>
              <p><b>2 400+</b> преподавателей уже создают с нами</p>
            </div>
          </div>
          <div className="hero-art" aria-label="Интерактивная иллюстрация учебных карточек">
            <div className="art-grid" />
            <div className="art-card art-card--back"><span>CSS</span></div>
            <div className="art-card art-card--middle"><span>02</span><b>Сопоставь пары</b></div>
            <div className="art-card art-card--front">
              <div className="art-card__top"><span>JS</span><small>1 / 8</small></div>
              <b>Какой метод добавит элемент в массив?</b>
              <div className="mini-option mini-option--active">A&nbsp;&nbsp; push()</div>
              <div className="mini-option">B&nbsp;&nbsp; slice()</div>
              <div className="mini-button">Проверить</div>
            </div>
            <div className="art-badge art-badge--top"><Icon name="spark" /> +120 XP</div>
            <div className="art-badge art-badge--bottom"><Icon name="check" /> Верно!</div>
          </div>
        </section>

        <section className="catalog" id="catalog">
          <div className="section-heading">
            <div>
              <div className="kicker">Витрина заданий</div>
              <div className="section-title">Выберите, что изучить сегодня</div>
            </div>
            <p>Короткие упражнения, понятный результат и никакой скучной теории.</p>
          </div>
          <div className="filters">
            <label className="search"><Icon name="search" /><input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Найти задание..." /></label>
            <select value={type} onChange={(event) => setType(event.target.value)}>
              {typeOptions.map((option) => <option key={option}>{option}</option>)}
            </select>
            <select value={difficulty} onChange={(event) => setDifficulty(event.target.value)}>
              {difficultyOptions.map((option) => <option key={option}>{option}</option>)}
            </select>
            <span className="found">{filtered.length} найдено</span>
          </div>
          <div className="task-grid">
            {filtered.map((task) => <TaskCard key={task.id} task={task} onStart={setActiveTask} />)}
          </div>
          {filtered.length === 0 && <div className="empty"><Icon name="search" /><div>Ничего не нашли</div><p>Попробуйте изменить запрос или сбросить фильтры.</p></div>}
        </section>

        <section className="how" id="how">
          <div className="how__title">От идеи до результата — за минуты</div>
          <div className="steps">
            <div><span>01</span><Icon name="spark" /><b>Выберите формат</b><p>Тест, пары, сортировка или последовательность.</p></div>
            <div><span>02</span><Icon name="book" /><b>Добавьте содержание</b><p>Заполните вопросы и отметьте верные ответы.</p></div>
            <div><span>03</span><Icon name="time" /><b>Поделитесь</b><p>Ученики проходят задание и сразу видят результат.</p></div>
          </div>
        </section>
      </main>
      <footer><a className="brand" href="#"><span>IT</span><b>Taskflow</b></a><p>Интерактивное обучение, которое работает.</p><span>© 2026</span></footer>
      {createOpen && <CreatePanel onClose={() => setCreateOpen(false)} onCreate={createTask} />}
    </div>
  );
}
